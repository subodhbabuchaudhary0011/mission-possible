import re
import secrets
import sqlite3
import threading
from functools import wraps

from flask import Flask, g, jsonify, redirect, render_template, request, session
from flask_socketio import SocketIO, join_room
from werkzeug.security import check_password_hash, generate_password_hash

from database import INSTANCE_DIR, db, init_db, now_iso

init_db()


def load_secret_key():
    path = INSTANCE_DIR / "secret.key"
    if not path.exists():
        path.write_text(secrets.token_hex(32))
    return path.read_text().strip()


app = Flask(__name__)
app.config.update(
    SECRET_KEY=load_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=64 * 1024,
)
socketio = SocketIO(app, async_mode="threading", max_http_buffer_size=32 * 1024)

USERNAME_RE = re.compile(r"[A-Za-z0-9_]{3,20}")
MAX_MESSAGE_LENGTH = 2000
PAGE_SIZE = 50

online = {}
online_lock = threading.Lock()


def error(message, status=400):
    return jsonify(error=message), status


def json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def valid_id(value):
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def parse_id_list(value):
    if not isinstance(value, list) or len(value) > 100:
        return None
    ids = []
    for item in value:
        if not valid_id(item):
            return None
        if item not in ids:
            ids.append(item)
    return ids


def existing_user_ids(conn, ids):
    marks = ",".join("?" * len(ids))
    rows = conn.execute(f"SELECT id FROM users WHERE id IN ({marks})", ids).fetchall()
    return {row["id"] for row in rows}


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    with db() as conn:
        return conn.execute(
            "SELECT id, username FROM users WHERE id = ?", (user_id,)
        ).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if user is None:
            session.clear()
            return error("Authentication required", 401)
        g.user = user
        return view(*args, **kwargs)

    return wrapped


def is_member(conn, conversation_id, user_id):
    row = conn.execute(
        "SELECT 1 FROM members WHERE conversation_id = ? AND user_id = ?",
        (conversation_id, user_id),
    ).fetchone()
    return row is not None


def conversation_dict(conn, conversation_id, viewer_id):
    conv = conn.execute(
        "SELECT id, type, name, created_by, created_at FROM conversations WHERE id = ?",
        (conversation_id,),
    ).fetchone()
    members = conn.execute(
        "SELECT u.id, u.username FROM members m JOIN users u ON u.id = m.user_id "
        "WHERE m.conversation_id = ? ORDER BY u.username",
        (conversation_id,),
    ).fetchall()
    last = conn.execute(
        "SELECT m.id, m.content, m.created_at, m.sender_id, u.username AS sender_name "
        "FROM messages m JOIN users u ON u.id = m.sender_id "
        "WHERE m.conversation_id = ? ORDER BY m.id DESC LIMIT 1",
        (conversation_id,),
    ).fetchone()
    unread = conn.execute(
        "SELECT COUNT(*) FROM messages WHERE conversation_id = ? AND sender_id != ? "
        "AND id > (SELECT last_read_id FROM members WHERE conversation_id = ? AND user_id = ?)",
        (conversation_id, viewer_id, conversation_id, viewer_id),
    ).fetchone()[0]

    data = {
        "id": conv["id"],
        "type": conv["type"],
        "created_by": conv["created_by"],
        "created_at": conv["created_at"],
        "members": [{"id": m["id"], "username": m["username"]} for m in members],
        "last_message": dict(last) if last else None,
        "unread": unread,
    }
    if conv["type"] == "private":
        other = next((m for m in members if m["id"] != viewer_id), None)
        data["name"] = other["username"] if other else "Unknown"
        data["other_user_id"] = other["id"] if other else None
    else:
        data["name"] = conv["name"]
    return data


def push_conversation(event, conversation_id, user_ids, join=False):
    room = f"conv_{conversation_id}"
    with db() as conn:
        views = {uid: conversation_dict(conn, conversation_id, uid) for uid in user_ids}
    for uid, view in views.items():
        if join:
            with online_lock:
                sids = list(online.get(uid, ()))
            for sid in sids:
                socketio.server.enter_room(sid, room, namespace="/")
        socketio.emit(event, view, to=f"user_{uid}")


def disconnect_user(user_id):
    with online_lock:
        sids = list(online.get(user_id, ()))
    for sid in sids:
        socketio.server.disconnect(sid, namespace="/")


@app.route("/")
def index():
    user = current_user()
    if user is None:
        return redirect("/login")
    return render_template("index.html", me={"id": user["id"], "username": user["username"]})


@app.route("/login")
def login_page():
    if current_user() is not None:
        return redirect("/")
    return render_template("auth.html")


@app.post("/api/register")
def register():
    data = json_body()
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    if not USERNAME_RE.fullmatch(username):
        return error("Username must be 3-20 characters: letters, numbers or underscore")
    if not 6 <= len(password) <= 128:
        return error("Password must be 6-128 characters")
    try:
        with db() as conn:
            cur = conn.execute(
                "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
                (username, generate_password_hash(password), now_iso()),
            )
            user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        return error("Username is already taken", 409)
    session.clear()
    session["user_id"] = user_id
    return jsonify(id=user_id, username=username), 201


@app.post("/api/login")
def login():
    data = json_body()
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    with db() as conn:
        user = conn.execute(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            (username,),
        ).fetchone()
    if user is None or not check_password_hash(user["password_hash"], password):
        return error("Invalid username or password", 401)
    session.clear()
    session["user_id"] = user["id"]
    return jsonify(id=user["id"], username=user["username"])


@app.post("/api/logout")
def logout():
    user_id = session.get("user_id")
    session.clear()
    if user_id:
        disconnect_user(user_id)
    return jsonify(ok=True)


@app.get("/api/me")
@login_required
def me():
    return jsonify(id=g.user["id"], username=g.user["username"])


@app.get("/api/users")
@login_required
def search_users():
    q = request.args.get("q", "").strip()[:30]
    pattern = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    with db() as conn:
        rows = conn.execute(
            "SELECT id, username FROM users WHERE id != ? AND username LIKE ? ESCAPE '\\' "
            "ORDER BY username LIMIT 20",
            (g.user["id"], pattern),
        ).fetchall()
    return jsonify([{"id": r["id"], "username": r["username"]} for r in rows])


@app.get("/api/conversations")
@login_required
def list_conversations():
    viewer_id = g.user["id"]
    with db() as conn:
        ids = [
            row["conversation_id"]
            for row in conn.execute(
                "SELECT conversation_id FROM members WHERE user_id = ?", (viewer_id,)
            )
        ]
        items = [conversation_dict(conn, cid, viewer_id) for cid in ids]

    def activity(c):
        last = c["last_message"]
        return (
            last["created_at"] if last else c["created_at"],
            last["id"] if last else 0,
            c["id"],
        )

    items.sort(key=activity, reverse=True)
    return jsonify(items)


@app.post("/api/conversations/private")
@login_required
def create_private():
    other_id = json_body().get("user_id")
    me_id = g.user["id"]
    if not valid_id(other_id):
        return error("Invalid user")
    if other_id == me_id:
        return error("You cannot start a chat with yourself")
    pair_key = f"{min(me_id, other_id)}:{max(me_id, other_id)}"
    created = False
    with db() as conn:
        if conn.execute("SELECT 1 FROM users WHERE id = ?", (other_id,)).fetchone() is None:
            return error("User not found", 404)
        row = conn.execute(
            "SELECT id FROM conversations WHERE pair_key = ?", (pair_key,)
        ).fetchone()
        if row is not None:
            conversation_id = row["id"]
        else:
            now = now_iso()
            try:
                cur = conn.execute(
                    "INSERT INTO conversations (type, pair_key, created_by, created_at) "
                    "VALUES ('private', ?, ?, ?)",
                    (pair_key, me_id, now),
                )
                conversation_id = cur.lastrowid
                conn.executemany(
                    "INSERT INTO members (conversation_id, user_id, joined_at) VALUES (?, ?, ?)",
                    [(conversation_id, me_id, now), (conversation_id, other_id, now)],
                )
                created = True
            except sqlite3.IntegrityError:
                conversation_id = conn.execute(
                    "SELECT id FROM conversations WHERE pair_key = ?", (pair_key,)
                ).fetchone()["id"]
        conversation = conversation_dict(conn, conversation_id, me_id)
    if created:
        push_conversation("conversation_added", conversation_id, [me_id, other_id], join=True)
    return jsonify(conversation), 201 if created else 200


@app.post("/api/groups")
@login_required
def create_group():
    data = json_body()
    name = str(data.get("name", "")).strip()
    member_ids = parse_id_list(data.get("member_ids"))
    me_id = g.user["id"]
    if not 1 <= len(name) <= 40:
        return error("Group name must be 1-40 characters")
    if member_ids is None:
        return error("Invalid member list")
    member_ids = [uid for uid in member_ids if uid != me_id]
    if not member_ids:
        return error("Select at least one other member")
    with db() as conn:
        if len(existing_user_ids(conn, member_ids)) != len(member_ids):
            return error("One or more users do not exist")
        now = now_iso()
        cur = conn.execute(
            "INSERT INTO conversations (type, name, created_by, created_at) "
            "VALUES ('group', ?, ?, ?)",
            (name, me_id, now),
        )
        conversation_id = cur.lastrowid
        everyone = [me_id] + member_ids
        conn.executemany(
            "INSERT INTO members (conversation_id, user_id, joined_at) VALUES (?, ?, ?)",
            [(conversation_id, uid, now) for uid in everyone],
        )
        conversation = conversation_dict(conn, conversation_id, me_id)
    push_conversation("conversation_added", conversation_id, everyone, join=True)
    return jsonify(conversation), 201


@app.post("/api/groups/<int:conversation_id>/members")
@login_required
def add_members(conversation_id):
    user_ids = parse_id_list(json_body().get("user_ids"))
    me_id = g.user["id"]
    if not user_ids:
        return error("Select at least one user")
    with db() as conn:
        conv = conn.execute(
            "SELECT type, created_by FROM conversations WHERE id = ?", (conversation_id,)
        ).fetchone()
        if conv is None or not is_member(conn, conversation_id, me_id):
            return error("You are not a member of this group", 403)
        if conv["type"] != "group":
            return error("Members can only be added to groups")
        if conv["created_by"] != me_id:
            return error("Only the group admin can add members", 403)
        if len(existing_user_ids(conn, user_ids)) != len(user_ids):
            return error("One or more users do not exist")
        current = [
            row["user_id"]
            for row in conn.execute(
                "SELECT user_id FROM members WHERE conversation_id = ?", (conversation_id,)
            )
        ]
        new_ids = [uid for uid in user_ids if uid not in current]
        if not new_ids:
            return error("Selected users are already in the group", 409)
        now = now_iso()
        conn.executemany(
            "INSERT INTO members (conversation_id, user_id, joined_at) VALUES (?, ?, ?)",
            [(conversation_id, uid, now) for uid in new_ids],
        )
        conversation = conversation_dict(conn, conversation_id, me_id)
    push_conversation("conversation_added", conversation_id, new_ids, join=True)
    push_conversation("group_updated", conversation_id, current)
    return jsonify(conversation)


@app.get("/api/conversations/<int:conversation_id>/messages")
@login_required
def get_messages(conversation_id):
    before = request.args.get("before", type=int)
    with db() as conn:
        if not is_member(conn, conversation_id, g.user["id"]):
            return error("You are not a member of this conversation", 403)
        sql = (
            "SELECT m.id, m.conversation_id, m.sender_id, u.username AS sender_name, "
            "m.content, m.created_at FROM messages m JOIN users u ON u.id = m.sender_id "
            "WHERE m.conversation_id = ?"
        )
        params = [conversation_id]
        if before:
            sql += " AND m.id < ?"
            params.append(before)
        sql += " ORDER BY m.id DESC LIMIT ?"
        params.append(PAGE_SIZE + 1)
        rows = conn.execute(sql, params).fetchall()
    has_more = len(rows) > PAGE_SIZE
    rows = rows[:PAGE_SIZE]
    rows.reverse()
    return jsonify(messages=[dict(r) for r in rows], has_more=has_more)


@app.post("/api/conversations/<int:conversation_id>/read")
@login_required
def mark_read(conversation_id):
    with db() as conn:
        if not is_member(conn, conversation_id, g.user["id"]):
            return error("You are not a member of this conversation", 403)
        conn.execute(
            "UPDATE members SET last_read_id = COALESCE("
            "(SELECT MAX(id) FROM messages WHERE conversation_id = ?), 0) "
            "WHERE conversation_id = ? AND user_id = ?",
            (conversation_id, conversation_id, g.user["id"]),
        )
    return jsonify(ok=True)


@socketio.on("connect")
def on_connect(auth=None):
    user_id = session.get("user_id")
    if not user_id:
        return False
    with db() as conn:
        if conn.execute("SELECT 1 FROM users WHERE id = ?", (user_id,)).fetchone() is None:
            return False
        conversation_ids = [
            row["conversation_id"]
            for row in conn.execute(
                "SELECT conversation_id FROM members WHERE user_id = ?", (user_id,)
            )
        ]
    sid = request.sid
    join_room(f"user_{user_id}")
    for conversation_id in conversation_ids:
        join_room(f"conv_{conversation_id}")
    with online_lock:
        sids = online.setdefault(user_id, set())
        first_connection = not sids
        sids.add(sid)
        online_ids = list(online.keys())
    socketio.emit("presence_list", online_ids, to=sid)
    if first_connection:
        socketio.emit("presence", {"user_id": user_id, "online": True})


@socketio.on("disconnect")
def on_disconnect(reason=None):
    sid = request.sid
    user_id = None
    went_offline = False
    with online_lock:
        for uid, sids in online.items():
            if sid in sids:
                sids.discard(sid)
                user_id = uid
                if not sids:
                    del online[uid]
                    went_offline = True
                break
    if went_offline:
        socketio.emit("presence", {"user_id": user_id, "online": False})


@socketio.on("send_message")
def on_send_message(data):
    user_id = session.get("user_id")
    if not user_id:
        return {"ok": False, "error": "Not authenticated"}
    if not isinstance(data, dict):
        return {"ok": False, "error": "Invalid message"}
    conversation_id = data.get("conversation_id")
    content = data.get("content")
    if not valid_id(conversation_id) or not isinstance(content, str):
        return {"ok": False, "error": "Invalid message"}
    content = content.strip()
    if not content:
        return {"ok": False, "error": "Message is empty"}
    if len(content) > MAX_MESSAGE_LENGTH:
        return {"ok": False, "error": f"Message is longer than {MAX_MESSAGE_LENGTH} characters"}
    with db() as conn:
        if not is_member(conn, conversation_id, user_id):
            return {"ok": False, "error": "You are not a member of this conversation"}
        sender = conn.execute("SELECT username FROM users WHERE id = ?", (user_id,)).fetchone()
        if sender is None:
            return {"ok": False, "error": "Not authenticated"}
        created_at = now_iso()
        cur = conn.execute(
            "INSERT INTO messages (conversation_id, sender_id, content, created_at) "
            "VALUES (?, ?, ?, ?)",
            (conversation_id, user_id, content, created_at),
        )
        message = {
            "id": cur.lastrowid,
            "conversation_id": conversation_id,
            "sender_id": user_id,
            "sender_name": sender["username"],
            "content": content,
            "created_at": created_at,
        }
    socketio.emit("new_message", message, to=f"conv_{conversation_id}")
    return {"ok": True}


if __name__ == "__main__":
    socketio.run(app, host="127.0.0.1", port=5000, debug=False, allow_unsafe_werkzeug=True)
