(() => {
  const tabs = document.querySelectorAll('.tab');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const isLogin = tab.dataset.tab === 'login';
      tabs.forEach((t) => t.classList.toggle('active', t === tab));
      loginForm.hidden = !isLogin;
      registerForm.hidden = isLogin;
    });
  });

  async function submit(form, url, body, errorEl) {
    errorEl.textContent = '';
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        credentials: 'same-origin',
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Something went wrong');
      window.location.href = '/';
    } catch (err) {
      errorEl.textContent = err.message;
      button.disabled = false;
    }
  }

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    submit(
      loginForm,
      '/api/login',
      { username: loginForm.elements.username.value, password: loginForm.elements.password.value },
      document.getElementById('loginError')
    );
  });

  registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const errorEl = document.getElementById('registerError');
    const { username, password, confirm } = registerForm.elements;
    if (password.value !== confirm.value) {
      errorEl.textContent = 'Passwords do not match';
      return;
    }
    submit(registerForm, '/api/register', { username: username.value, password: password.value }, errorEl);
  });
})();
