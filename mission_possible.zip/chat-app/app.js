(() => {
  'use strict';

  const me = window.ME;
  const $ = (id) => document.getElementById(id);

  const els = {
    app: $('app'),
    meAvatar: $('meAvatar'),
    meName: $('meName'),
    newGroupBtn: $('newGroupBtn'),
    logoutBtn: $('logoutBtn'),
    connBanner: $('connBanner'),
    searchInput: $('searchInput'),
    listTitle: $('listTitle'),
    list: $('list'),
    emptyState: $('emptyState'),
    panel: $('panel'),
    backBtn: $('backBtn'),
    headerAvatar: $('headerAvatar'),
    chatTitle: $('chatTitle'),
    chatSub: $('chatSub'),
    addMembersBtn: $('addMembersBtn'),
    messages: $('messages'),
    loadMore: $('loadMore'),
    messageList: $('messageList'),
    composer: $('composer'),
    messageInput: $('messageInput'),
    toast: $('toast'),
  };

  const state = {
    conversations: new Map(),
    activeId: null,
    online: new Set(),
    messageIds: new Set(),
    oldestId: null,
    hasMore: false,
    loadingOlder: false,
    searching: false,
    searchResults: null,
  };

  const PALETTE = ['#0e6b55', '#1b7f9e', '#7a5ea8', '#b05a3c', '#9a7d1f', '#3d7d3a', '#8a4a6b', '#456b8a'];

  function colorFor(name) {
    let h = 0;
    for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
    return PALETTE[Math.abs(h) % PALETTE.length];
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function avatar(name, isGroup, size) {
    const label = name || '?';
    const node = el(
      'div',
      'avatar' + (isGroup ? ' group' : '') + (size ? ' ' + size : ''),
      label.charAt(0).toUpperCase()
    );
    node.style.background = colorFor(label);
    return node;
  }

  function presenceDot(userId) {
    return el('span', 'dot ' + (state.online.has(userId) ? 'online' : 'offline'));
  }

  function emptyItem(text) {
    return el('li', 'list-empty', text);
  }

  let toastTimer;
  function toast(message) {
    els.toast.textContent = message;
    els.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { els.toast.hidden = true; }, 3500);
  }

  async function api(url, options = {}) {
    const init = { method: options.method || 'GET', headers: {}, credentials: 'same-origin' };
    if (options.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(options.body);
    }
    const res = await fetch(url, init);
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (res.status === 401) {
      window.location.href = '/login';
      throw new Error('Session expired');
    }
    if (!res.ok) throw new Error((data && data.error) || 'Request failed');
    return data;
  }

  function isToday(date) {
    return date.toDateString() === new Date().toDateString();
  }

  function clock(date) {
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }

  function dayLabel(date) {
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }

  function fullTime(iso) {
    const date = new Date(iso);
    return isToday(date) ? clock(date) : dayLabel(date) + ', ' + clock(date);
  }

  function shortTime(iso) {
    const date = new Date(iso);
    return isToday(date) ? clock(date) : dayLabel(date);
  }

  function sortedConversations() {
    const key = (c) => (c.last_message ? c.last_message.created_at : c.created_at);
    const lastId = (c) => (c.last_message ? c.last_message.id : 0);
    return [...state.conversations.values()].sort((a, b) => {
      const ka = key(a);
      const kb = key(b);
      if (ka !== kb) return ka < kb ? 1 : -1;
      return lastId(b) - lastId(a) || b.id - a.id;
    });
  }

  function previewText(c) {
    const m = c.last_message;
    if (!m) return c.type === 'group' ? 'Group created' : 'No messages yet';
    if (m.sender_id === me.id) return 'You: ' + m.content;
    return c.type === 'group' ? m.sender_name + ': ' + m.content : m.content;
  }

  function conversationRow(c) {
    const li = el('li', 'item' + (c.id === state.activeId ? ' active' : ''));
    const av = avatar(c.name, c.type === 'group');
    if (c.type === 'private') av.append(presenceDot(c.other_user_id));

    const body = el('div', 'item-body');
    const top = el('div', 'item-top');
    top.append(
      el('span', 'item-name', c.name),
      el('span', 'item-time', c.last_message ? shortTime(c.last_message.created_at) : '')
    );
    const bottom = el('div', 'item-bottom');
    bottom.append(el('span', 'item-preview', previewText(c)));
    if (c.unread > 0) bottom.append(el('span', 'badge', c.unread > 99 ? '99+' : String(c.unread)));
    body.append(top, bottom);

    li.append(av, body);
    li.addEventListener('click', () => openConversation(c.id));
    return li;
  }

  function userRow(user) {
    const li = el('li', 'item');
    const av = avatar(user.username, false);
    av.append(presenceDot(user.id));
    const body = el('div', 'item-body');
    const top = el('div', 'item-top');
    top.append(el('span', 'item-name', user.username));
    const bottom = el('div', 'item-bottom');
    bottom.append(el('span', 'item-preview', state.online.has(user.id) ? 'online' : 'offline'));
    body.append(top, bottom);
    li.append(av, body);
    li.addEventListener('click', () => openPrivate(user.id));
    return li;
  }

  function renderList() {
    const scrollTop = els.list.scrollTop;
    let nodes;
    if (state.searching) {
      els.listTitle.textContent = 'Users';
      if (state.searchResults === null) nodes = [emptyItem('Searching...')];
      else if (!state.searchResults.length) nodes = [emptyItem('No users found')];
      else nodes = state.searchResults.map(userRow);
    } else {
      els.listTitle.textContent = 'Chats';
      const items = sortedConversations();
      nodes = items.length
        ? items.map(conversationRow)
        : [emptyItem('No chats yet. Search for a user above to start one.')];
    }
    els.list.replaceChildren(...nodes);
    els.list.scrollTop = scrollTop;
  }

  function renderHeader() {
    const c = state.conversations.get(state.activeId);
    if (!c) return;
    const av = avatar(c.name, c.type === 'group');
    if (c.type === 'private') av.append(presenceDot(c.other_user_id));
    els.headerAvatar.replaceChildren(av);
    els.chatTitle.textContent = c.name;

    if (c.type === 'private') {
      const isOnline = state.online.has(c.other_user_id);
      els.chatSub.textContent = isOnline ? 'online' : 'offline';
      els.chatSub.classList.toggle('online', isOnline);
    } else {
      const onlineCount = c.members.filter((m) => state.online.has(m.id)).length;
      const names = c.members.map((m) => (m.id === me.id ? 'You' : m.username)).join(', ');
      els.chatSub.textContent = onlineCount + ' online · ' + names;
      els.chatSub.classList.remove('online');
    }
    els.addMembersBtn.hidden = !(c.type === 'group' && c.created_by === me.id);
  }

  function messageNode(m) {
    const mine = m.sender_id === me.id;
    const row = el('div', 'msg ' + (mine ? 'mine' : 'theirs'));
    const bubble = el('div', 'bubble');
    const sender = el('div', 'sender', mine ? 'You' : m.sender_name);
    if (!mine) sender.style.color = colorFor(m.sender_name);
    bubble.append(sender, el('div', 'text', m.content), el('div', 'time', fullTime(m.created_at)));
    row.append(bubble);
    return row;
  }

  function addMessage(m) {
    if (state.messageIds.has(m.id)) return;
    state.messageIds.add(m.id);
    els.messageList.append(messageNode(m));
  }

  function isNearBottom() {
    const box = els.messages;
    return box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  }

  function scrollToBottom() {
    els.messages.scrollTop = els.messages.scrollHeight;
  }

  function renderMessages(messages, hasMore) {
    els.messageList.replaceChildren();
    state.messageIds = new Set();
    state.oldestId = messages.length ? messages[0].id : null;
    state.hasMore = hasMore;
    els.loadMore.hidden = !hasMore;
    messages.forEach(addMessage);
    scrollToBottom();
  }

  async function loadOlder() {
    const id = state.activeId;
    if (!id || !state.hasMore || state.loadingOlder) return;
    state.loadingOlder = true;
    try {
      const data = await api('/api/conversations/' + id + '/messages?before=' + state.oldestId);
      if (state.activeId !== id) return;
      const previousHeight = els.messages.scrollHeight;
      const fragment = document.createDocumentFragment();
      data.messages.forEach((m) => {
        if (state.messageIds.has(m.id)) return;
        state.messageIds.add(m.id);
        fragment.append(messageNode(m));
      });
      els.messageList.prepend(fragment);
      if (data.messages.length) state.oldestId = data.messages[0].id;
      state.hasMore = data.has_more;
      els.loadMore.hidden = !data.has_more;
      els.messages.scrollTop += els.messages.scrollHeight - previousHeight;
    } catch (err) {
      toast(err.message);
    } finally {
      state.loadingOlder = false;
    }
  }

  function markRead(id) {
    api('/api/conversations/' + id + '/read', { method: 'POST' }).catch(() => {});
  }

  function clearSearch() {
    els.searchInput.value = '';
    state.searching = false;
    state.searchResults = null;
  }

  function closeChat() {
    state.activeId = null;
    els.panel.hidden = true;
    els.emptyState.hidden = false;
    els.app.classList.remove('chat-open');
    renderList();
  }

  async function openConversation(id) {
    const c = state.conversations.get(id);
    if (!c) return;
    state.activeId = id;
    c.unread = 0;
    clearSearch();
    els.app.classList.add('chat-open');
    els.emptyState.hidden = true;
    els.panel.hidden = false;
    els.messageList.replaceChildren();
    els.loadMore.hidden = true;
    renderHeader();
    renderList();
    try {
      const data = await api('/api/conversations/' + id + '/messages');
      if (state.activeId !== id) return;
      renderMessages(data.messages, data.has_more);
      markRead(id);
    } catch (err) {
      toast(err.message);
    }
    if (window.matchMedia('(min-width: 769px)').matches) els.messageInput.focus();
  }

  function upsertConversation(c) {
    if (c.id === state.activeId) c.unread = 0;
    state.conversations.set(c.id, c);
    renderList();
    if (c.id === state.activeId) renderHeader();
  }

  async function openPrivate(userId) {
    try {
      const c = await api('/api/conversations/private', { method: 'POST', body: { user_id: userId } });
      upsertConversation(c);
      openConversation(c.id);
    } catch (err) {
      toast(err.message);
    }
  }

  async function refreshAll() {
    try {
      const list = await api('/api/conversations');
      state.conversations = new Map(list.map((c) => [c.id, c]));
      if (state.activeId !== null && !state.conversations.has(state.activeId)) {
        closeChat();
        return;
      }
      if (state.activeId !== null) {
        const id = state.activeId;
        state.conversations.get(id).unread = 0;
        renderHeader();
        const data = await api('/api/conversations/' + id + '/messages');
        if (state.activeId === id) {
          renderMessages(data.messages, data.has_more);
          markRead(id);
        }
      }
      renderList();
    } catch (err) {
      toast(err.message);
    }
  }

  const socket = io();

  function setConnected(connected) {
    els.connBanner.hidden = connected;
  }

  socket.on('connect', () => {
    setConnected(true);
    refreshAll();
  });

  socket.on('disconnect', async (reason) => {
    setConnected(false);
    if (reason === 'io server disconnect') {
      try {
        await api('/api/me');
        socket.connect();
      } catch (err) { }
    }
  });

  socket.on('connect_error', async () => {
    setConnected(false);
    try { await api('/api/me'); } catch (err) { }
  });

  socket.on('presence_list', (ids) => {
    state.online = new Set(ids);
    renderList();
    renderHeader();
  });

  socket.on('presence', (data) => {
    if (data.online) state.online.add(data.user_id);
    else state.online.delete(data.user_id);
    renderList();
    renderHeader();
  });

  socket.on('conversation_added', upsertConversation);
  socket.on('group_updated', upsertConversation);

  socket.on('new_message', (m) => {
    const c = state.conversations.get(m.conversation_id);
    if (!c) {
      refreshAll();
      return;
    }
    c.last_message = {
      id: m.id,
      content: m.content,
      created_at: m.created_at,
      sender_id: m.sender_id,
      sender_name: m.sender_name,
    };
    const mine = m.sender_id === me.id;
    if (m.conversation_id === state.activeId) {
      const stick = mine || isNearBottom();
      addMessage(m);
      if (stick) scrollToBottom();
      if (!mine) markRead(c.id);
    } else if (!mine) {
      c.unread = (c.unread || 0) + 1;
    }
    renderList();
  });

  els.composer.addEventListener('submit', (e) => {
    e.preventDefault();
    const content = els.messageInput.value.trim();
    if (!content || state.activeId === null) return;
    if (!socket.connected) {
      toast('Not connected. Trying to reconnect...');
      return;
    }
    els.messageInput.value = '';
    socket.emit('send_message', { conversation_id: state.activeId, content }, (res) => {
      if (!res || !res.ok) {
        toast((res && res.error) || 'Message could not be sent');
        if (!els.messageInput.value) els.messageInput.value = content;
      }
    });
  });

  els.loadMore.addEventListener('click', loadOlder);
  els.backBtn.addEventListener('click', closeChat);

  let searchTimer;
  els.searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = els.searchInput.value.trim();
    if (!q) {
      state.searching = false;
      state.searchResults = null;
      renderList();
      return;
    }
    state.searching = true;
    renderList();
    searchTimer = setTimeout(async () => {
      try {
        const users = await api('/api/users?q=' + encodeURIComponent(q));
        if (els.searchInput.value.trim() !== q) return;
        state.searchResults = users;
        renderList();
      } catch (err) {
        toast(err.message);
      }
    }, 200);
  });

  function createPicker(root, getExcluded) {
    const chips = el('div', 'chips');
    const input = el('input');
    input.type = 'search';
    input.placeholder = 'Search users';
    input.maxLength = 30;
    input.autocomplete = 'off';
    const results = el('ul', 'list picker-list');
    root.replaceChildren(chips, input, results);

    const selected = new Map();
    let lastUsers = [];
    let timer;

    function toggle(user) {
      if (selected.has(user.id)) selected.delete(user.id);
      else selected.set(user.id, user);
      renderChips();
      renderResults(lastUsers);
    }

    function renderChips() {
      chips.replaceChildren(
        ...[...selected.values()].map((user) => {
          const chip = el('button', 'chip', user.username + ' ✕');
          chip.type = 'button';
          chip.addEventListener('click', () => toggle(user));
          return chip;
        })
      );
    }

    function renderResults(users) {
      lastUsers = users;
      const excluded = getExcluded();
      const visible = users.filter((u) => !excluded.has(u.id));
      if (!visible.length) {
        results.replaceChildren(emptyItem('No users found'));
        return;
      }
      results.replaceChildren(
        ...visible.map((user) => {
          const li = el('li', 'item' + (selected.has(user.id) ? ' selected' : ''));
          const body = el('div', 'item-body');
          body.append(el('span', 'item-name', user.username));
          li.append(avatar(user.username, false, 'sm'), body, el('span', 'check', selected.has(user.id) ? '✓' : ''));
          li.addEventListener('click', () => toggle(user));
          return li;
        })
      );
    }

    async function search() {
      try {
        renderResults(await api('/api/users?q=' + encodeURIComponent(input.value.trim())));
      } catch (err) {
        toast(err.message);
      }
    }

    input.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(search, 200);
    });

    return {
      selectedIds: () => [...selected.keys()],
      reset() {
        selected.clear();
        input.value = '';
        renderChips();
        search();
      },
    };
  }

  function hideModals() {
    document.querySelectorAll('.modal').forEach((modal) => { modal.hidden = true; });
  }

  document.querySelectorAll('.modal').forEach((modal) => {
    modal.addEventListener('mousedown', (e) => {
      if (e.target === modal) modal.hidden = true;
    });
    modal.querySelectorAll('[data-close]').forEach((btn) => {
      btn.addEventListener('click', () => { modal.hidden = true; });
    });
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') hideModals();
  });

  const groupPicker = createPicker($('groupPicker'), () => new Set([me.id]));
  const addPicker = createPicker($('addPicker'), () => {
    const c = state.conversations.get(state.activeId);
    return new Set(c ? c.members.map((m) => m.id) : []);
  });

  els.newGroupBtn.addEventListener('click', () => {
    $('groupName').value = '';
    $('groupError').textContent = '';
    groupPicker.reset();
    $('groupModal').hidden = false;
    $('groupName').focus();
  });

  $('groupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = $('groupError');
    const button = e.target.querySelector('button[type="submit"]');
    const memberIds = groupPicker.selectedIds();
    if (!memberIds.length) {
      errorEl.textContent = 'Select at least one member';
      return;
    }
    errorEl.textContent = '';
    button.disabled = true;
    try {
      const c = await api('/api/groups', {
        method: 'POST',
        body: { name: $('groupName').value.trim(), member_ids: memberIds },
      });
      upsertConversation(c);
      hideModals();
      openConversation(c.id);
    } catch (err) {
      errorEl.textContent = err.message;
    } finally {
      button.disabled = false;
    }
  });

  els.addMembersBtn.addEventListener('click', () => {
    $('addError').textContent = '';
    addPicker.reset();
    $('addModal').hidden = false;
  });

  $('addForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = $('addError');
    const button = e.target.querySelector('button[type="submit"]');
    const userIds = addPicker.selectedIds();
    if (!userIds.length) {
      errorEl.textContent = 'Select at least one user';
      return;
    }
    errorEl.textContent = '';
    button.disabled = true;
    try {
      const c = await api('/api/groups/' + state.activeId + '/members', {
        method: 'POST',
        body: { user_ids: userIds },
      });
      upsertConversation(c);
      hideModals();
    } catch (err) {
      errorEl.textContent = err.message;
    } finally {
      button.disabled = false;
    }
  });

  els.logoutBtn.addEventListener('click', async () => {
    try {
      await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
    } catch (err) { }
    socket.disconnect();
    window.location.href = '/login';
  });

  els.meName.textContent = me.username;
  els.meAvatar.replaceWith(avatar(me.username, false));
  renderList();
})();
